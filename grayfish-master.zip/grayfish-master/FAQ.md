<b>Does it verify passwords ?</b><br>
No it doesn't. It just simple demonstration how fake page can look like normal website page.<br><br>

<b>Your Connection is not private ?</b><br>
https://github.com/graysuit/grayfish/blob/master/remove_if_https.htaccess#L7-L9<br>
https://support.thinkific.com/hc/en-us/articles/360030362114-Fix-Insecure-Content-on-Your-Site<br>

<b>000webhost is started detecting it:</b><br>
This is because a lot of people are using grayfish. Thats why its files signature came in to their database. So probably they don't allow phishing experiments.<br><br>

<b>Facebook started detecting it:</b><br>
It isn't detecting untill now. Because we don't allow their user agents to see phish page.<br>
So may be link is shared a lot times or may be domain name is already banned.<br>
